#define NANOSVG_IMPLEMENTATION
#define NANOSVGRAST_IMPLEMENTATION

#include <stdio.h>
#include "nanosvg.h"
#include "nanosvgrast.h"
