#pragma once

#include "rcheevos/include/rconsoles.h"

bool generateHashFromFile(char hash[33], int console_id, const char* path);
